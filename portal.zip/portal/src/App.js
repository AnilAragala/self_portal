import React, { useContext } from "react";
import { Route } from "react-router-dom";
import { MenuContext } from "react-flexible-sliding-menu";
import logo from "./images/abbott.png";
import menuIcon from "./images/menuicon.png";
import Dashboard from "./components/Dashboard";

function App() {
  const { toggleMenu } = useContext(MenuContext);
  return (
    <div className="App">
      {/* <div> */}

      {/* <div className="container" onClick={toggleMenu}>
        <div className="bar1"></div>
        <div className="bar2"></div>
        <div className="bar3"></div>
      </div> */}
      <div className="container">
        <img
          className="menuimage"
          alt=" menu icon"
          src={menuIcon}
          onClick={toggleMenu}
        />
        <img className="abbott_logo" alt="Abbott Logo" src={logo} />
        <span className="portal">Self Service Portal</span>
        <input type="search" className="search_input" placeholder="Search" />
      </div>
      <Dashboard />
      {/* </div> */}

      <Route exact path="/" component={() => <h2></h2>} />
      <Route path="/dashboard" component={() => <h2>Dashboard Component</h2>} />
      <Route path="/gallery" component={() => <h2>Gallery Component</h2>} />
    </div>
  );
}

export default App;
