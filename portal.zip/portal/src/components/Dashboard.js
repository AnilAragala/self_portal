import React from "react";
import "./css/dashboard.css";
import UpcomingPatches from "./UpcomingPatches";
import CatalogServices from "./CatalogServices";

function Dashboard() {
  return (
    <div className="dashboard_container">
      <div className="mydashboard">
        <h2 className="dashboard">My Dashboard</h2>
        <div className="tasks_list">
          <h1>45</h1>
          <span>Total Tasks</span>
        </div>
        <div className="tasks_list">
          <h1>5</h1>
          <span>Pending</span>
        </div>
        <div className="tasks_list">
          <h1>60</h1>
          <span>Completed</span>
        </div>
        <div className="tasks_list">
          <h1>33</h1>
          <span># of Assets</span>
        </div>
        <div className="tasks_list">
          <h1>6</h1>
          <span># of Support</span>
        </div>
        <div className="container1">Grafana Dashboard</div>
        <CatalogServices />
      </div>
      <UpcomingPatches />
    </div>
  );
}

export default Dashboard;
